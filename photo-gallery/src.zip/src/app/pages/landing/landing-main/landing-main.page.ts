import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-main',
  templateUrl: './landing-main.page.html',
  styleUrls: ['./landing-main.page.scss'],
})
export class LandingMainPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
