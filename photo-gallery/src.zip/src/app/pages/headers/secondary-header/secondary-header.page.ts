import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondary-header',
  templateUrl: './secondary-header.page.html',
  styleUrls: ['./secondary-header.page.scss'],
})
export class SecondaryHeaderPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
